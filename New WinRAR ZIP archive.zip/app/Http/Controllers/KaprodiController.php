<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class KaprodiController extends Controller
{
    //
    public function datasempro(){
    	$data = DB::table('proposalsempro' )
    	->where('status','=','Disetujui')
    	->join('users AS u','proposalsempro.id_user','=','u.id')
    	->join('users AS us','proposalsempro.id_dosen','=','us.id')
    	->select('proposalsempro.*','u.name as nameMhs','u.nim as nimMhs','us.name as nameDosen')
    	->get();
    	return view('kaprodi.datasempro',compact('data'));

    	
    }
}
