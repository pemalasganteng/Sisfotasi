<?php $__env->startSection('content'); ?>
<div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Thead info</h4>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table class="table text-center">
                                            <thead class="text-uppercase bg-info">
                                                <tr class="text-white">
                                                    <th scope="col">NO</th>
                                                    <th scope="col">Tanggal Pengajuan</th>
                                                    <th scope="col">Nama</th>
                                                    <th scope="col">Pembimbing</th>
                                                    <th scope="col">Status</th>
                                                    <th scope="col">Aksi</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                
                                                <tr>
                                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                                    <td><?php echo e(date('d-m-Y H:i:s',strtotime($d->created_at))); ?></td>
                                                    <td><?php echo e($d->nameMhs); ?><br><?php echo e($d->nimMhs); ?></td>
                                                    
                                                    <td><?php echo e($d->nameDosen); ?></td>
                                                    <td><?php echo e($d->status); ?><br><?php echo e($d->updated_at); ?></i></td>
                                                    <td><button class="btn btn-rounded btn-info mb-3" data-toggle="modal" data-target="#exampleModal">Jadwalkan</button></td>
                                                </tr>

                                                
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisfotasi2\resources\views/kaprodi/datasempro.blade.php ENDPATH**/ ?>