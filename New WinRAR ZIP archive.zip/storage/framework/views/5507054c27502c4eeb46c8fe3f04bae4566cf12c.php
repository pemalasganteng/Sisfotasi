<?php $__env->startSection('content'); ?>

<div class="col-lg-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Pengajuan Seminar Proposal</h4>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table class="table text-center">
                                            <thead class="text-uppercase bg-dark">
                                                <tr class="text-white">
                                                    <th scope="col">ID</th>
                                                    <th scope="col">Judul</th>
                                                    <th scope="col">Abstrak</th>
                                                    <th scope="col">Dokumen File</th>
                                                    <th scope="col">Tanggal Pengajuan</th>
                                                    <th scope="col">Status Diterima</th>
                                                    <th scope="col">Status Terjadwal</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                	<?php $__currentLoopData = $sempro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <th scope="row">1</th>
                                                    <td><?php echo e($s->judul); ?></td>
                                                    <td><?php echo e($s->abstrak); ?></td>
                                                    <td><a href="<?php echo e(asset('filesempro/'.$s->file)); ?>"> <?php echo e($s->file); ?></a></td>
                                                    <td><?php echo e(date('d/m/Y', strtotime($s->created_at))); ?></td>
                                                    <td>
                                                    	<?php if($s->status == 'Belum Disetujui'): ?>
                                                    	<i class="fa fa-minus"></i>
                                                    	<?php elseif($s->status == 'Disetujui'): ?>
                                                    	<i class="fa fa-check"></i>
                                                    	<?php elseif($s->status == 'Ditolak'): ?>
                                                    	<i class="fa fa-close"></i>
                                                    	<?php endif; ?>
                                                    </td>
                                                    <td>Belum Terjadwal</td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="alert alert-primary" role="alert">
                                            <h4 class="alert-heading"><i class="fa fa-info"></i> Informasi!</h4>
                                            <p><i class="fa fa-minus"> Belum Disetujui Pembimbing</i></p>
                                            <p><i class="fa fa-check"> Disetujui Pembimbing</i></p>
                                            <p><i class="fa fa-close"> Ditolak Pembimbing</i></p>
                                            <hr>
                                            <p class="mb-0">Jika ada kesulitan hubungi <code>Administrator.</code></p>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisfotasi2\resources\views/sempro.blade.php ENDPATH**/ ?>