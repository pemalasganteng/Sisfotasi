-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2019 at 01:28 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sisfotasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `bimbingan`
--

CREATE TABLE `bimbingan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `ket_revisi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_acc` date NOT NULL,
  `id_user` bigint(20) UNSIGNED NOT NULL,
  `id_dosen` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bimbingan_detail`
--

CREATE TABLE `bimbingan_detail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_bimbingan` bigint(20) UNSIGNED NOT NULL,
  `bimbinganke` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_11_11_091517_create_proposalsempro_table', 1),
(4, '2019_11_12_091810_create_tahaptaskripsi_table', 1),
(5, '2019_11_12_093824_create_semprojadwal_table', 1),
(6, '2019_11_12_102637_create_ruang_table', 1),
(7, '2019_11_12_102724_create_waktu_table', 1),
(8, '2019_11_12_103106_create_rwdetail_table', 1),
(9, '2019_11_12_104729_create_prodi_table', 1),
(10, '2019_11_12_105850_create_periode_table', 1),
(11, '2019_11_12_111817_create_bimbingan_table', 1),
(12, '2019_11_12_112727_create_bimbingan_detail_table', 1),
(13, '2019_11_12_113533_create_taskripsijadwal_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `periode`
--

CREATE TABLE `periode` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_periode` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `periode`
--

INSERT INTO `periode` (`id`, `nama_periode`, `semester`, `tanggal_mulai`, `tanggal_selesai`, `status`, `created_at`, `updated_at`) VALUES
(1, '2019', 'Gasal', '2019-11-12', '2019-12-31', 'buka', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `prodi`
--

CREATE TABLE `prodi` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_prodi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `prodi`
--

INSERT INTO `prodi` (`id`, `nama_prodi`, `created_at`, `updated_at`) VALUES
(1, 'D3 Manajemen Informatika', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `proposalsempro`
--

CREATE TABLE `proposalsempro` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abstrak` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_dosen` bigint(20) UNSIGNED NOT NULL,
  `id_user` bigint(20) UNSIGNED NOT NULL,
  `id_periode` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `proposalsempro`
--

INSERT INTO `proposalsempro` (`id`, `judul`, `abstrak`, `file`, `file2`, `status`, `id_dosen`, `id_user`, `id_periode`, `created_at`, `updated_at`) VALUES
(1, 'Rancang Bangun Website', 'Lorem ipsum dolor sit amet Lorem ipsum dolor sit ametLorem ipsum dolor sit amet Lorem ipsum dolor sit amet', 'de3e1f6985a09abfe2d13502661c5185.pdf', NULL, 'Disetujui', 2, 1, 1, '2019-11-12 07:51:04', '2019-11-16 09:19:10');

-- --------------------------------------------------------

--
-- Table structure for table `ruang`
--

CREATE TABLE `ruang` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_ruang` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ruang`
--

INSERT INTO `ruang` (`id`, `nama_ruang`, `created_at`, `updated_at`) VALUES
(1, 'A10.02.01', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rwdetail`
--

CREATE TABLE `rwdetail` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_ruang` bigint(20) UNSIGNED NOT NULL,
  `id_waktu` bigint(20) UNSIGNED NOT NULL,
  `id_jadwal` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `semprojadwal`
--

CREATE TABLE `semprojadwal` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_dosen1` bigint(20) UNSIGNED NOT NULL,
  `id_dosen2` bigint(20) UNSIGNED NOT NULL,
  `id_ruang` bigint(20) UNSIGNED NOT NULL,
  `id_waktu` bigint(20) UNSIGNED NOT NULL,
  `id_proposalsempro` bigint(20) UNSIGNED NOT NULL,
  `id_tahap` bigint(20) UNSIGNED NOT NULL,
  `id_user` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tahaptaskripsi`
--

CREATE TABLE `tahaptaskripsi` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status_pengajuansempro` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_jadwalsempro` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_revisisempro` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_penilitian` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_pendaftaranujian` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_ujianjadwal` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_revisita` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_laporanfileselesai` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_proposalsempro` bigint(20) UNSIGNED NOT NULL,
  `id_semprojadwal` bigint(20) UNSIGNED NOT NULL,
  `id_user` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taskripsijadwal`
--

CREATE TABLE `taskripsijadwal` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_dosen` bigint(20) UNSIGNED NOT NULL,
  `id_dosen2` bigint(20) UNSIGNED NOT NULL,
  `tanggal` date NOT NULL,
  `id_waktu` bigint(20) UNSIGNED NOT NULL,
  `id_ruang` bigint(20) UNSIGNED NOT NULL,
  `id_proposalsempro` bigint(20) UNSIGNED NOT NULL,
  `id_user` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nim` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_membimbing` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_prodi` bigint(20) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `nim`, `status_membimbing`, `id_prodi`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Jihad Satrio Utama', 'jihad@unesa.ac.id', NULL, '$2y$10$WQvHDQFtBFtKXWYgeV3Ide2QdA3IkjUGr4wbDNWJnheafUXrcDFXm', '3', '17050623024', '', 1, NULL, NULL, NULL),
(2, 'Ali S.Kom., M.Kom.', 'dosen1@unesa.ac.id', NULL, '$2y$10$WQvHDQFtBFtKXWYgeV3Ide2QdA3IkjUGr4wbDNWJnheafUXrcDFXm', '2', '191919199191', 'buka', 1, NULL, NULL, NULL),
(3, 'Sugik', 'kaprodi@unesa.ac.id', NULL, '$2y$10$WQvHDQFtBFtKXWYgeV3Ide2QdA3IkjUGr4wbDNWJnheafUXrcDFXm', '1', '', '', 1, NULL, NULL, NULL),
(4, 'Supratman S.T., M.T.', 'dosen2@unesa.ac.id', NULL, '$2y$10$WQvHDQFtBFtKXWYgeV3Ide2QdA3IkjUGr4wbDNWJnheafUXrcDFXm', '2', '10101010101', 'buka', 1, NULL, NULL, NULL),
(5, 'Prof. Alan S.T., M.Kom.', 'dosen3@unesa.ac.id', NULL, '$2y$10$WQvHDQFtBFtKXWYgeV3Ide2QdA3IkjUGr4wbDNWJnheafUXrcDFXm', '2', '19270001093', 'buka', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `waktu`
--

CREATE TABLE `waktu` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sesi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_akhir` time NOT NULL,
  `id_ruang` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `waktu`
--

INSERT INTO `waktu` (`id`, `sesi`, `jam_mulai`, `jam_akhir`, `id_ruang`, `created_at`, `updated_at`) VALUES
(2, '1', '07:00:00', '08:40:00', 1, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bimbingan`
--
ALTER TABLE `bimbingan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bimbingan_id_user_foreign` (`id_user`),
  ADD KEY `bimbingan_id_dosen_foreign` (`id_dosen`);

--
-- Indexes for table `bimbingan_detail`
--
ALTER TABLE `bimbingan_detail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bimbingan_detail_id_bimbingan_foreign` (`id_bimbingan`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `periode`
--
ALTER TABLE `periode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prodi`
--
ALTER TABLE `prodi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `proposalsempro`
--
ALTER TABLE `proposalsempro`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proposalsempro_id_dosen_foreign` (`id_dosen`),
  ADD KEY `proposalsempro_id_user_foreign` (`id_user`),
  ADD KEY `proposalsempro_id_periode_foreign` (`id_periode`);

--
-- Indexes for table `ruang`
--
ALTER TABLE `ruang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rwdetail`
--
ALTER TABLE `rwdetail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rwdetail_id_ruang_foreign` (`id_ruang`),
  ADD KEY `rwdetail_id_waktu_foreign` (`id_waktu`),
  ADD KEY `rwdetail_id_jadwal_foreign` (`id_jadwal`);

--
-- Indexes for table `semprojadwal`
--
ALTER TABLE `semprojadwal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `semprojadwal_id_dosen1_foreign` (`id_dosen1`),
  ADD KEY `semprojadwal_id_dosen2_foreign` (`id_dosen2`),
  ADD KEY `semprojadwal_id_ruang_foreign` (`id_ruang`),
  ADD KEY `semprojadwal_id_waktu_foreign` (`id_waktu`),
  ADD KEY `semprojadwal_id_proposalsempro_foreign` (`id_proposalsempro`),
  ADD KEY `semprojadwal_id_tahap_foreign` (`id_tahap`),
  ADD KEY `semprojadwal_id_user_foreign` (`id_user`);

--
-- Indexes for table `tahaptaskripsi`
--
ALTER TABLE `tahaptaskripsi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tahaptaskripsi_id_proposalsempro_foreign` (`id_proposalsempro`),
  ADD KEY `tahaptaskripsi_id_semprojadwal_foreign` (`id_semprojadwal`),
  ADD KEY `tahaptaskripsi_id_user_foreign` (`id_user`);

--
-- Indexes for table `taskripsijadwal`
--
ALTER TABLE `taskripsijadwal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `taskripsijadwal_id_dosen_foreign` (`id_dosen`),
  ADD KEY `taskripsijadwal_id_dosen2_foreign` (`id_dosen2`),
  ADD KEY `taskripsijadwal_id_waktu_foreign` (`id_waktu`),
  ADD KEY `taskripsijadwal_id_ruang_foreign` (`id_ruang`),
  ADD KEY `taskripsijadwal_id_proposalsempro_foreign` (`id_proposalsempro`),
  ADD KEY `taskripsijadwal_id_user_foreign` (`id_user`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `waktu`
--
ALTER TABLE `waktu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `waktu_id_ruang_foreign` (`id_ruang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bimbingan`
--
ALTER TABLE `bimbingan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bimbingan_detail`
--
ALTER TABLE `bimbingan_detail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `periode`
--
ALTER TABLE `periode`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `prodi`
--
ALTER TABLE `prodi`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `proposalsempro`
--
ALTER TABLE `proposalsempro`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ruang`
--
ALTER TABLE `ruang`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rwdetail`
--
ALTER TABLE `rwdetail`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `semprojadwal`
--
ALTER TABLE `semprojadwal`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tahaptaskripsi`
--
ALTER TABLE `tahaptaskripsi`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `taskripsijadwal`
--
ALTER TABLE `taskripsijadwal`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `waktu`
--
ALTER TABLE `waktu`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bimbingan`
--
ALTER TABLE `bimbingan`
  ADD CONSTRAINT `bimbingan_id_dosen_foreign` FOREIGN KEY (`id_dosen`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bimbingan_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bimbingan_detail`
--
ALTER TABLE `bimbingan_detail`
  ADD CONSTRAINT `bimbingan_detail_id_bimbingan_foreign` FOREIGN KEY (`id_bimbingan`) REFERENCES `bimbingan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `proposalsempro`
--
ALTER TABLE `proposalsempro`
  ADD CONSTRAINT `proposalsempro_id_dosen_foreign` FOREIGN KEY (`id_dosen`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `proposalsempro_id_periode_foreign` FOREIGN KEY (`id_periode`) REFERENCES `periode` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `proposalsempro_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `rwdetail`
--
ALTER TABLE `rwdetail`
  ADD CONSTRAINT `rwdetail_id_jadwal_foreign` FOREIGN KEY (`id_jadwal`) REFERENCES `semprojadwal` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rwdetail_id_ruang_foreign` FOREIGN KEY (`id_ruang`) REFERENCES `ruang` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rwdetail_id_waktu_foreign` FOREIGN KEY (`id_waktu`) REFERENCES `waktu` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `semprojadwal`
--
ALTER TABLE `semprojadwal`
  ADD CONSTRAINT `semprojadwal_id_dosen1_foreign` FOREIGN KEY (`id_dosen1`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `semprojadwal_id_dosen2_foreign` FOREIGN KEY (`id_dosen2`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `semprojadwal_id_proposalsempro_foreign` FOREIGN KEY (`id_proposalsempro`) REFERENCES `proposalsempro` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `semprojadwal_id_ruang_foreign` FOREIGN KEY (`id_ruang`) REFERENCES `ruangwaktudetail` (`id_ruang`) ON DELETE CASCADE,
  ADD CONSTRAINT `semprojadwal_id_tahap_foreign` FOREIGN KEY (`id_tahap`) REFERENCES `tahaptaskripsi` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `semprojadwal_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `semprojadwal_id_waktu_foreign` FOREIGN KEY (`id_waktu`) REFERENCES `ruangwaktudetail` (`id_waktu`) ON DELETE CASCADE;

--
-- Constraints for table `tahaptaskripsi`
--
ALTER TABLE `tahaptaskripsi`
  ADD CONSTRAINT `tahaptaskripsi_id_proposalsempro_foreign` FOREIGN KEY (`id_proposalsempro`) REFERENCES `proposalsempro` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tahaptaskripsi_id_semprojadwal_foreign` FOREIGN KEY (`id_semprojadwal`) REFERENCES `semprojadwal` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tahaptaskripsi_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `taskripsijadwal`
--
ALTER TABLE `taskripsijadwal`
  ADD CONSTRAINT `taskripsijadwal_id_dosen2_foreign` FOREIGN KEY (`id_dosen2`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `taskripsijadwal_id_dosen_foreign` FOREIGN KEY (`id_dosen`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `taskripsijadwal_id_proposalsempro_foreign` FOREIGN KEY (`id_proposalsempro`) REFERENCES `proposalsempro` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `taskripsijadwal_id_ruang_foreign` FOREIGN KEY (`id_ruang`) REFERENCES `rwdetail` (`id_ruang`) ON DELETE CASCADE,
  ADD CONSTRAINT `taskripsijadwal_id_user_foreign` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `taskripsijadwal_id_waktu_foreign` FOREIGN KEY (`id_waktu`) REFERENCES `rwdetail` (`id_waktu`) ON DELETE CASCADE;

--
-- Constraints for table `waktu`
--
ALTER TABLE `waktu`
  ADD CONSTRAINT `waktu_id_ruang_foreign` FOREIGN KEY (`id_ruang`) REFERENCES `ruang` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
